
using CareerLync.Api.Enums;

namespace CareerLync.Api.DTOs;

public record SignUpDTO(
    string Name,
    string Email,
    string Password,
    UserRole Role,
    string? HighestEducation,
    string? Skills,
    string? CompanyName,
    string? Website,
    string? CompanyDetails
);

public record LoginDTO(string Email, string Password);

public record AuthResponse(int UserId, string Email, UserRole Role, string Token);
