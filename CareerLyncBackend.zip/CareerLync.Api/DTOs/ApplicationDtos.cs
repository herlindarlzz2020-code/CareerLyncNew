
using CareerLync.Api.Enums;

namespace CareerLync.Api.DTOs;

public record ApplyJobDTO(int JobListingId);
public record ApplicationDTO(int Id, int JobListingId, string JobTitle, ApplicationStatus Status, DateTime AppliedDate);
public record UpdateApplicationStatusDTO(ApplicationStatus Status);
