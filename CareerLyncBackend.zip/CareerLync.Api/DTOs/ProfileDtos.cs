
namespace CareerLync.Api.DTOs;

public record UpdateProfileDTO(
    string? Name,
    string? Mob,
    string? Address,
    DateTime? Dob,
    string? HighestEducation,
    string? Skills,
    string? CompanyName,
    string? Website,
    string? CompanyDetails
);
