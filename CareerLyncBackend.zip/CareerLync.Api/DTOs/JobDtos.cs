
using CareerLync.Api.Enums;

namespace CareerLync.Api.DTOs;

public record JobCreateDTO(
    string JobTitle,
    string Company,
    string? JobDescription,
    string? Location,
    string? Requirements,
    decimal? Salary
);

public record JobUpdateDTO(
    string JobTitle,
    string Company,
    string? JobDescription,
    string? Location,
    string? Requirements,
    decimal? Salary,
    bool? IsDeleted
);

public record JobDTO(
    int Id,
    string JobTitle,
    string Company,
    string? JobDescription,
    string? Location,
    string? Requirements,
    decimal? Salary,
    DateTime PostedDate,
    int EmployerId
);
