
namespace CareerLync.Api.Enums
{
    public enum UserRole
    {
        Admin = 0,
        Employer = 1,
        JobSeeker = 2
    }

    public enum ApplicationStatus
    {
        Pending = 0,
        Shortlisted = 1,
        Selected = 2,
        Rejected = 3
    }
}
