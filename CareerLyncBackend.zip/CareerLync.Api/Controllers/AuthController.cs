
using System.Security.Claims;
using CareerLync.Api.DTOs;
using CareerLync.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IUserService _users;

    public AuthController(IUserService users)
    {
        _users = users;
    }

    [HttpPost("signup")]
    public async Task<ActionResult<AuthResponse>> SignUp([FromBody] SignUpDTO dto)
    {
        try
        {
            var res = await _users.SignUpAsync(dto);
            return Ok(res);
        }
        catch (Exception ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPost("signin")]
    public async Task<ActionResult<AuthResponse>> SignIn([FromBody] LoginDTO dto)
    {
        try
        {
            var res = await _users.SignInAsync(dto.Email, dto.Password);
            return Ok(res);
        }
        catch (Exception ex)
        {
            return Unauthorized(new { message = ex.Message });
        }
    }
}
