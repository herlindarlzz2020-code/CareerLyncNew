
using System.Security.Claims;
using CareerLync.Api.DTOs;
using CareerLync.Api.Enums;
using CareerLync.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Api.Controllers;

[ApiController]
[Route("api/employer")]
[Authorize(Roles = nameof(UserRole.Employer))]
public class EmployerController : ControllerBase
{
    private readonly IJobService _jobs;
    private readonly IApplicationService _apps;

    public EmployerController(IJobService jobs, IApplicationService apps)
    {
        _jobs = jobs;
        _apps = apps;
    }

    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpPost("job")]
    public async Task<ActionResult<JobDTO>> CreateJob([FromBody] JobCreateDTO dto)
        => Ok(await _jobs.CreateAsync(UserId, dto));

    [HttpPut("job/{id:int}")]
    public async Task<ActionResult<JobDTO>> UpdateJob(int id, [FromBody] JobUpdateDTO dto)
        => Ok(await _jobs.UpdateAsync(UserId, id, dto));

    [HttpGet("jobs")]
    public async Task<ActionResult<IEnumerable<JobDTO>>> MyJobs()
        => Ok(await _jobs.GetMyJobsAsync(UserId));

    [HttpGet("job/{id:int}/applications")]
    public async Task<ActionResult<IEnumerable<ApplicationDTO>>> ApplicationsForJob(int id)
        => Ok(await _apps.ApplicationsForJobAsync(UserId, id));

    [HttpPut("application/{id:int}/status")]
    public async Task<ActionResult<ApplicationDTO>> UpdateStatus(int id, [FromBody] UpdateApplicationStatusDTO dto)
        => Ok(await _apps.UpdateStatusAsync(UserId, id, dto));

    [HttpDelete("job/{id:int}")]
    public async Task<ActionResult> SoftDelete(int id)
    {
        await _jobs.SoftDeleteAsync(UserId, id);
        return Ok(new { message = "Deleted" });
    }
}
