
using System.Security.Claims;
using CareerLync.Api.DTOs;
using CareerLync.Api.Enums;
using CareerLync.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Api.Controllers;

[ApiController]
[Route("api/jobseeker")]
[Authorize(Roles = nameof(UserRole.JobSeeker))]
public class JobSeekerController : ControllerBase
{
    private readonly IJobService _jobs;
    private readonly IApplicationService _apps;
    private readonly IResumeService _resumes;
    private readonly IUserService _users;

    public JobSeekerController(IJobService jobs, IApplicationService apps, IResumeService resumes, IUserService users)
    {
        _jobs = jobs;
        _apps = apps;
        _resumes = resumes;
        _users = users;
    }

    private int UserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [HttpGet("search")]
    [AllowAnonymous]
    public async Task<ActionResult<IEnumerable<JobDTO>>> Search([FromQuery] string? keyword)
        => Ok(await _jobs.SearchAsync(keyword));

    [HttpPost("apply")]
    public async Task<ActionResult<ApplicationDTO>> Apply([FromBody] ApplyJobDTO dto)
        => Ok(await _apps.ApplyAsync(UserId, dto));

    [HttpGet("applications")]
    public async Task<ActionResult<IEnumerable<ApplicationDTO>>> MyApplications()
        => Ok(await _apps.MyApplicationsAsync(UserId));

    [HttpPost("upload-resume")]
    [RequestSizeLimit(25_000_000)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult> UploadResume([FromForm] IFormFile file)
    {
        if (file is null || file.Length == 0) return BadRequest(new { message = "Invalid file" });
        using var ms = new MemoryStream();
        await file.CopyToAsync(ms);
        await _resumes.UploadAsync(UserId, ms.ToArray());
        return Ok(new { message = "Uploaded" });
    }

    [HttpPut("profile")]
    public async Task<ActionResult> UpdateProfile([FromBody] UpdateProfileDTO dto)
    {
        await _users.UpdateProfileAsync(UserId, dto);
        return Ok(new { message = "Updated" });
    }
}
