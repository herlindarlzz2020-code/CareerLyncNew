
using CareerLync.Api.Enums;
using CareerLync.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Api.Controllers;

[ApiController]
[Route("api/admin")]
[Authorize(Roles = nameof(UserRole.Admin))]
public class AdminController : ControllerBase
{
    private readonly IUserService _users;
    private readonly IJobService _jobs;

    public AdminController(IUserService users, IJobService jobs)
    {
        _users = users;
        _jobs = jobs;
    }

    [HttpDelete("user/{id:int}")]
    public async Task<ActionResult> SoftDeleteUser(int id)
    {
        await _users.SoftDeleteUserAsync(id);
        return Ok(new { message = "Deleted" });
    }

    [HttpDelete("job/{id:int}")]
    public async Task<ActionResult> SoftDeleteJob(int id)
    {
        await _jobs.AdminSoftDeleteAsync(id);
        return Ok(new { message = "Deleted" });
    }
}
