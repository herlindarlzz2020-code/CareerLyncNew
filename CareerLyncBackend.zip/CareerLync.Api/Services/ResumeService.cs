
using CareerLync.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Api.Services;

public class ResumeService : IResumeService
{
    private readonly AppDbContext _db;
    public ResumeService(AppDbContext db) => _db = db;

    public async Task UploadAsync(int userId, byte[] fileBytes)
    {
        var existing = await _db.Resumes.FirstOrDefaultAsync(r => r.UserId == userId);
        if (existing is null)
        {
            _db.Resumes.Add(new Models.Resume
            {
                UserId = userId,
                FileBytes = fileBytes,
                UploadedAt = DateTime.UtcNow
            });
        }
        else
        {
            existing.FileBytes = fileBytes;
            existing.UploadedAt = DateTime.UtcNow;
        }
        await _db.SaveChangesAsync();
    }
}
