
namespace CareerLync.Api.Services;

public interface IResumeService
{
    Task UploadAsync(int userId, byte[] fileBytes);
}
