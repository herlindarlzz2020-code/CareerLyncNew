
using CareerLync.Api.Data;
using CareerLync.Api.DTOs;
using CareerLync.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Api.Services;

public class JobService : IJobService
{
    private readonly AppDbContext _db;
    public JobService(AppDbContext db) => _db = db;

    public async Task<JobDTO> CreateAsync(int employerId, JobCreateDTO dto)
    {
        var job = new JobListing
        {
            EmployerId = employerId,
            JobTitle = dto.JobTitle,
            Company = dto.Company,
            JobDescription = dto.JobDescription,
            Location = dto.Location,
            Requirements = dto.Requirements,
            Salary = dto.Salary,
            PostedDate = DateTime.UtcNow
        };
        _db.JobListings.Add(job);
        await _db.SaveChangesAsync();
        return ToDto(job);
    }

    public async Task<JobDTO> UpdateAsync(int employerId, int jobId, JobUpdateDTO dto)
    {
        var job = await _db.JobListings.FirstOrDefaultAsync(j => j.Id == jobId && j.EmployerId == employerId);
        if (job is null) throw new Exception("Job not found.");
        job.JobTitle = dto.JobTitle;
        job.Company = dto.Company;
        job.JobDescription = dto.JobDescription;
        job.Location = dto.Location;
        job.Requirements = dto.Requirements;
        job.Salary = dto.Salary;
        if (dto.IsDeleted == true) job.IsDeleted = true;
        await _db.SaveChangesAsync();
        return ToDto(job);
    }

    public async Task<IEnumerable<JobDTO>> GetMyJobsAsync(int employerId)
    {
        var jobs = await _db.JobListings.Where(j => j.EmployerId == employerId).OrderByDescending(j => j.PostedDate).ToListAsync();
        return jobs.Select(ToDto);
    }

    public async Task<IEnumerable<JobDTO>> SearchAsync(string? keyword)
    {
        var q = _db.JobListings.AsQueryable();
        if (!string.IsNullOrWhiteSpace(keyword))
        {
            q = q.Where(j => j.JobTitle.Contains(keyword) || j.Company.Contains(keyword) || (j.JobDescription ?? "").Contains(keyword));
        }
        var jobs = await q.OrderByDescending(j => j.PostedDate).ToListAsync();
        return jobs.Select(ToDto);
    }

    public async Task SoftDeleteAsync(int employerId, int jobId)
    {
        var job = await _db.JobListings.FirstOrDefaultAsync(j => j.Id == jobId && j.EmployerId == employerId);
        if (job is null) throw new Exception("Job not found.");
        job.IsDeleted = true;
        await _db.SaveChangesAsync();
    }

    public async Task AdminSoftDeleteAsync(int jobId)
    {
        var job = await _db.JobListings.FirstOrDefaultAsync(j => j.Id == jobId);
        if (job is null) throw new Exception("Job not found.");
        job.IsDeleted = true;
        await _db.SaveChangesAsync();
    }

    private static JobDTO ToDto(JobListing j) =>
        new(j.Id, j.JobTitle, j.Company, j.JobDescription, j.Location, j.Requirements, j.Salary, j.PostedDate, j.EmployerId);
}
