
using CareerLync.Api.Data;
using CareerLync.Api.DTOs;
using CareerLync.Api.Enums;
using CareerLync.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Api.Services;

public class UserService : IUserService
{
    private readonly AppDbContext _db;
    private readonly IJwtProvider _jwt;

    public UserService(AppDbContext db, IJwtProvider jwt)
    {
        _db = db;
        _jwt = jwt;
    }

    public async Task<AuthResponse> SignUpAsync(SignUpDTO dto)
    {
        if (await _db.Users.IgnoreQueryFilters().AnyAsync(u => u.Email == dto.Email))
            throw new Exception("Email already registered.");

        var user = new User
        {
            Name = dto.Name,
            Email = dto.Email,
            Password = dto.Password, // NOTE: hash in production
            Role = dto.Role,
            HighestEducation = dto.Role == UserRole.JobSeeker ? dto.HighestEducation : null,
            Skills = dto.Role == UserRole.JobSeeker ? dto.Skills : null,
            CompanyName = dto.Role == UserRole.Employer ? dto.CompanyName : null,
            Website = dto.Role == UserRole.Employer ? dto.Website : null,
            CompanyDetails = dto.Role == UserRole.Employer ? dto.CompanyDetails : null
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        var token = _jwt.Create(user.Email, user.Id, user.Role);
        return new AuthResponse(user.Id, user.Email, user.Role, token);
    }

    public async Task<AuthResponse> SignInAsync(string email, string password)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email && u.Password == password);
        if (user is null) throw new Exception("Invalid credentials.");
        var token = _jwt.Create(user.Email, user.Id, user.Role);
        return new AuthResponse(user.Id, user.Email, user.Role, token);
    }

    public Task<User?> GetByIdAsync(int id) => _db.Users.FirstOrDefaultAsync(u => u.Id == id);

    public async Task SoftDeleteUserAsync(int id)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == id);
        if (user is null) throw new Exception("User not found.");
        user.IsDeleted = true;
        await _db.SaveChangesAsync();
    }

    public async Task UpdateProfileAsync(int userId, UpdateProfileDTO dto)
    {
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == userId);
        if (user is null) throw new Exception("User not found");

        if (dto.Name is not null) user.Name = dto.Name;
        if (dto.Mob is not null) user.Mob = dto.Mob;
        if (dto.Address is not null) user.Address = dto.Address;
        if (dto.Dob is not null) user.Dob = dto.Dob;
        if (dto.HighestEducation is not null) user.HighestEducation = dto.HighestEducation;
        if (dto.Skills is not null) user.Skills = dto.Skills;
        if (dto.CompanyName is not null) user.CompanyName = dto.CompanyName;
        if (dto.Website is not null) user.Website = dto.Website;
        if (dto.CompanyDetails is not null) user.CompanyDetails = dto.CompanyDetails;

        await _db.SaveChangesAsync();
    }
}
