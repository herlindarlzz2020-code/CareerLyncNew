
using CareerLync.Api.DTOs;

namespace CareerLync.Api.Services;

public interface IJobService
{
    Task<JobDTO> CreateAsync(int employerId, JobCreateDTO dto);
    Task<JobDTO> UpdateAsync(int employerId, int jobId, JobUpdateDTO dto);
    Task<IEnumerable<JobDTO>> GetMyJobsAsync(int employerId);
    Task<IEnumerable<JobDTO>> SearchAsync(string? keyword);
    Task SoftDeleteAsync(int employerId, int jobId);
    Task AdminSoftDeleteAsync(int jobId);
}
