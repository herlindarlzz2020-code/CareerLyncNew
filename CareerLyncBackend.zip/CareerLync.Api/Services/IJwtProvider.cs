
using CareerLync.Api.Enums;

namespace CareerLync.Api.Services;

public interface IJwtProvider
{
    string Create(string email, int userId, UserRole role);
}
