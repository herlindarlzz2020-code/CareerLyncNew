
using CareerLync.Api.DTOs;
using CareerLync.Api.Enums;
using CareerLync.Api.Models;

namespace CareerLync.Api.Services;

public interface IUserService
{
    Task<AuthResponse> SignUpAsync(SignUpDTO dto);
    Task<AuthResponse> SignInAsync(string email, string password);
    Task<User?> GetByIdAsync(int id);
    Task SoftDeleteUserAsync(int id);
    Task UpdateProfileAsync(int userId, UpdateProfileDTO dto);
}
