
using CareerLync.Api.DTOs;

namespace CareerLync.Api.Services;

public interface IApplicationService
{
    Task<ApplicationDTO> ApplyAsync(int jobSeekerId, ApplyJobDTO dto);
    Task<IEnumerable<ApplicationDTO>> MyApplicationsAsync(int jobSeekerId);
    Task<IEnumerable<ApplicationDTO>> ApplicationsForJobAsync(int employerId, int jobId);
    Task<ApplicationDTO> UpdateStatusAsync(int employerId, int applicationId, UpdateApplicationStatusDTO dto);
}
