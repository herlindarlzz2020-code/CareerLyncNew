
using CareerLync.Api.Data;
using CareerLync.Api.DTOs;
using CareerLync.Api.Enums;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Api.Services;

public class ApplicationService : IApplicationService
{
    private readonly AppDbContext _db;
    public ApplicationService(AppDbContext db) => _db = db;

    public async Task<ApplicationDTO> ApplyAsync(int jobSeekerId, ApplyJobDTO dto)
    {
        var job = await _db.JobListings.FirstOrDefaultAsync(j => j.Id == dto.JobListingId);
        if (job is null) throw new Exception("Job not found.");

        var exists = await _db.Applications.AnyAsync(a => a.JobSeekerId == jobSeekerId && a.JobListingId == dto.JobListingId);
        if (exists) throw new Exception("You have already applied for this job.");

        var app = new Models.Application
        {
            JobSeekerId = jobSeekerId,
            JobListingId = dto.JobListingId,
            Status = ApplicationStatus.Pending,
            AppliedDate = DateTime.UtcNow
        };
        _db.Applications.Add(app);
        await _db.SaveChangesAsync();

        return new ApplicationDTO(app.Id, app.JobListingId, job.JobTitle, app.Status, app.AppliedDate);
    }

    public async Task<IEnumerable<ApplicationDTO>> MyApplicationsAsync(int jobSeekerId)
    {
        var apps = await _db.Applications
            .Include(a => a.JobListing)
            .Where(a => a.JobSeekerId == jobSeekerId)
            .OrderByDescending(a => a.AppliedDate)
            .ToListAsync();
        return apps.Select(a => new ApplicationDTO(a.Id, a.JobListingId, a.JobListing!.JobTitle, a.Status, a.AppliedDate));
    }

    public async Task<IEnumerable<ApplicationDTO>> ApplicationsForJobAsync(int employerId, int jobId)
    {
        var job = await _db.JobListings.FirstOrDefaultAsync(j => j.Id == jobId && j.EmployerId == employerId);
        if (job is null) throw new Exception("Job not found.");

        var apps = await _db.Applications
            .Include(a => a.JobListing)
            .Include(a => a.JobSeeker)
            .Where(a => a.JobListingId == jobId)
            .ToListAsync();

        return apps.Select(a => new ApplicationDTO(a.Id, a.JobListingId, job.JobTitle, a.Status, a.AppliedDate));
    }

    public async Task<ApplicationDTO> UpdateStatusAsync(int employerId, int applicationId, UpdateApplicationStatusDTO dto)
    {
        var app = await _db.Applications
            .Include(a => a.JobListing)
            .FirstOrDefaultAsync(a => a.Id == applicationId && a.JobListing!.EmployerId == employerId);
        if (app is null) throw new Exception("Application not found.");
        app.Status = dto.Status;
        await _db.SaveChangesAsync();
        return new ApplicationDTO(app.Id, app.JobListingId, app.JobListing!.JobTitle, app.Status, app.AppliedDate);
    }
}
