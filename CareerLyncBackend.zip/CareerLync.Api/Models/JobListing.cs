
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CareerLync.Api.Models;

[Table("JobListings")]
public class JobListing
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required]
    public string JobTitle { get; set; } = string.Empty;

    [Required]
    public string Company { get; set; } = string.Empty;

    public string? JobDescription { get; set; }
    public string? Location { get; set; }
    public string? Requirements { get; set; }
    public decimal? Salary { get; set; }
    public DateTime PostedDate { get; set; } = DateTime.UtcNow;

    // Employer
    public int EmployerId { get; set; }
    public User? Employer { get; set; }

    public bool IsDeleted { get; set; } = false;

    public ICollection<Application> Applications { get; set; } = new List<Application>();
}
