
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CareerLync.Api.Enums;

namespace CareerLync.Api.Models;

[Table("Applications")]
public class Application
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public ApplicationStatus Status { get; set; } = ApplicationStatus.Pending;

    public DateTime AppliedDate { get; set; } = DateTime.UtcNow;

    // JobSeeker
    public int JobSeekerId { get; set; }
    public User? JobSeeker { get; set; }

    // Job
    public int JobListingId { get; set; }
    public JobListing? JobListing { get; set; }

    public bool IsDeleted { get; set; } = false;
}
