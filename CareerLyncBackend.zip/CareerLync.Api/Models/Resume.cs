
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CareerLync.Api.Models;

[Table("Resumes")]
public class Resume
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public byte[] FileBytes { get; set; } = Array.Empty<byte>();

    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;

    // 1-1 with User (JobSeeker)
    public int UserId { get; set; }
    public User? User { get; set; }

    public bool IsDeleted { get; set; } = false;
}
