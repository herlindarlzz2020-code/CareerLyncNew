
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CareerLync.Api.Enums;

namespace CareerLync.Api.Models;

[Table("Users")]
public class User
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    [Required, MaxLength(200)]
    public string Name { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Password { get; set; } = string.Empty;

    [MaxLength(20)]
    public string? Mob { get; set; }

    [MaxLength(300)]
    public string? Address { get; set; }

    public DateTime? Dob { get; set; }

    [Required]
    public UserRole Role { get; set; }

    // JobSeeker fields
    public string? HighestEducation { get; set; }
    public string? Skills { get; set; }

    // Employer fields
    public string? CompanyName { get; set; }
    public string? Website { get; set; }
    public string? CompanyDetails { get; set; }

    // Soft delete
    public bool IsDeleted { get; set; } = false;

    public Resume? Resume { get; set; } // 1-1 optional
}
