# CareerLync Frontend (React + React-Bootstrap)

This project is a plain **Create React App** (no Vite) with:
- React-Router for in-app navigation
- React-Bootstrap for UI (matches a clean Bootstrap theme)
- Axios with auth token interceptor
- Pages for JobSeeker, Employer, and Admin flows aligned to your backend

## Quick start

1) Ensure your backend runs on `http://localhost:5288` (or set an env var).
2) In this folder, run:
```
npm install
npm start
```
3) (Optional) To point to a different backend URL, create `.env` at project root:
```
REACT_APP_API_BASE_URL=http://localhost:5288
```

## Endpoints used (edit in `src/api/axios.js` or per page if yours differ)

- Auth:
  - `POST /api/Auth/signup`
  - `POST /api/Auth/signin`
- JobSeeker:
  - `GET  /api/jobseeker/search-jobs?keyword=...`
  - `POST /api/jobseeker/upload-resume` (multipart, fields: jobSeekerId, file)
  - `POST /api/jobseeker/apply` (body: { status, appliedDate, jobSeekerId, jobListingId })
- Employer:
  - `GET  /api/employer/jobs?employerId=...`
  - `POST /api/employer/post-job`
  - `GET  /api/employer/applications/{jobId}`
  - `PUT  /api/employer/applications/{applicationId}/status` (body: { status: 'Selected' })
- Admin:
  - `GET  /api/admin/jobseekers`
  - `GET  /api/admin/employers`
  - `DELETE /api/admin/jobseekers/{uid}` (soft delete)
  - `DELETE /api/admin/employers/{uid}` (soft delete)

If your backend uses different paths or fields, update the calls inside the page files.

## Styling

- Imports Bootstrap 5 from `node_modules`.
- Components keep a consistent light theme, card shadows, and spacing.
- Adjust theme further by overriding CSS or using Bootstrap variables.
