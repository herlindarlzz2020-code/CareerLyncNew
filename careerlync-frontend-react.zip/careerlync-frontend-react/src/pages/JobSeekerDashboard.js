import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Table, Alert } from 'react-bootstrap';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function JobSeekerDashboard() {
  const { uid } = useAuth();
  const [keyword, setKeyword] = useState('');
  const [jobs, setJobs] = useState([]);
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const searchJobs = async () => {
    try {
      const res = await api.get('/api/jobseeker/search-jobs', { params: { keyword } });
      setJobs(res.data || []);
      setMessage('');
    } catch (err) {
      setError('Failed to fetch jobs');
    }
  };

  const uploadResume = async () => {
    if (!file) return;
    const form = new FormData();
    form.append('jobSeekerId', uid);
    form.append('file', file);
    try {
      await api.post('/api/jobseeker/upload-resume', form, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setMessage('Resume uploaded');
    } catch (err) {
      setError('Upload failed');
    }
  };

  const apply = async (jobId) => {
    try {
      const payload = {
        status: 'Pending',
        appliedDate: new Date().toISOString(),
        jobSeekerId: parseInt(uid),
        jobListingId: jobId
      };
      await api.post('/api/jobseeker/apply', payload);
      setMessage('Applied!');
    } catch (err) {
      setError('Apply failed');
    }
  };

  return (
    <Container className="py-4">
      <Row className="mb-3">
        <Col><h3>Job Seeker Dashboard</h3></Col>
      </Row>

      {message && <Alert variant="success">{message}</Alert>}
      {error && <Alert variant="danger">{error}</Alert>}

      <Card className="mb-4 shadow-sm">
        <Card.Body>
          <Row className="g-2">
            <Col md={8}>
              <Form.Control placeholder="Search jobs..." value={keyword} onChange={(e)=>setKeyword(e.target.value)} />
            </Col>
            <Col md={4}>
              <Button onClick={searchJobs} className="w-100">Search</Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card className="mb-4 shadow-sm">
        <Card.Body>
          <Row className="g-2 align-items-center">
            <Col md={8}>
              <Form.Control type="file" onChange={(e)=>setFile(e.target.files[0])} />
            </Col>
            <Col md={4}>
              <Button onClick={uploadResume} className="w-100">Upload Resume</Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card className="shadow-sm">
        <Card.Body>
          <h5>Results</h5>
          <Table responsive>
            <thead>
              <tr>
                <th>Title</th>
                <th>Company</th>
                <th>Location</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {jobs.map(j => (
                <tr key={j.jobId}>
                  <td>{j.jobTitle}</td>
                  <td>{j.company}</td>
                  <td>{j.location}</td>
                  <td><Button size="sm" onClick={()=>apply(j.jobId)}>Apply</Button></td>
                </tr>
              ))}
              {!jobs.length && <tr><td colSpan="4" className="text-muted">No results</td></tr>}
            </tbody>
          </Table>
        </Card.Body>
      </Card>
    </Container>
  );
}
