import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Table, Alert, Button } from 'react-bootstrap';
import api from '../api/axios';

export default function AdminDashboard() {
  const [jobSeekers, setJobSeekers] = useState([]);
  const [employers, setEmployers] = useState([]);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const load = async () => {
    try {
      const [js, em] = await Promise.all([
        api.get('/api/admin/jobseekers'),
        api.get('/api/admin/employers'),
      ]);
      setJobSeekers(js.data || []);
      setEmployers(em.data || []);
    } catch (err) {
      setError('Failed to load data');
    }
  };

  useEffect(()=>{ load(); }, []);

  const softDelete = async (role, uid) => {
    try {
      await api.delete(`/api/admin/${role}/${uid}`);
      setMessage('User soft-deleted');
      load();
    } catch (err) {
      setError('Delete failed');
    }
  };

  return (
    <Container className="py-4">
      <Row className="mb-3"><Col><h3>Admin Dashboard</h3></Col></Row>
      {message && <Alert variant="success">{message}</Alert>}
      {error && <Alert variant="danger">{error}</Alert>}

      <Card className="mb-4 shadow-sm">
        <Card.Body>
          <h5>Job Seekers</h5>
          <Table responsive>
            <thead><tr><th>UID</th><th>Name</th><th>Email</th><th>Action</th></tr></thead>
            <tbody>
              {jobSeekers.map(u => (
                <tr key={u.uid}>
                  <td>{u.uid}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td><Button size="sm" variant="outline-danger" onClick={()=>softDelete('jobseekers', u.uid)}>Delete</Button></td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      <Card className="shadow-sm">
        <Card.Body>
          <h5>Employers</h5>
          <Table responsive>
            <thead><tr><th>UID</th><th>Name</th><th>Email</th><th>Action</th></tr></thead>
            <tbody>
              {employers.map(u => (
                <tr key={u.uid}>
                  <td>{u.uid}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td><Button size="sm" variant="outline-danger" onClick={()=>softDelete('employers', u.uid)}>Delete</Button></td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>
    </Container>
  );
}
