import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Table, Alert, Modal } from 'react-bootstrap';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function EmployerDashboard() {
  const { uid } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState({ jobTitle: '', company: '', jobDescription: '', location: '', requirements: '', salary: 0 });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showApplicants, setShowApplicants] = useState(false);
  const [applicants, setApplicants] = useState([]);
  const [activeJobId, setActiveJobId] = useState(null);

  const loadJobs = async () => {
    try {
      const res = await api.get('/api/employer/jobs', { params: { employerId: uid } });
      setJobs(res.data || []);
    } catch (err) {
      setError('Failed to load jobs');
    }
  };

  useEffect(()=>{ loadJobs(); }, []);

  const postJob = async () => {
    try {
      const payload = { ...form, employerId: parseInt(uid) };
      await api.post('/api/employer/post-job', payload);
      setMessage('Job posted');
      setForm({ jobTitle: '', company: '', jobDescription: '', location: '', requirements: '', salary: 0 });
      loadJobs();
    } catch (err) {
      setError('Failed to post job');
    }
  };

  const openApplicants = async (jobId) => {
    try {
      const res = await api.get(`/api/employer/applications/${jobId}`);
      setApplicants(res.data || []);
      setActiveJobId(jobId);
      setShowApplicants(true);
    } catch (err) {
      setError('Failed to load applicants');
    }
  };

  const selectCandidate = async (applicationId) => {
    try {
      await api.put(`/api/employer/applications/${applicationId}/status`, { status: 'Selected' });
      setMessage('Candidate selected');
      openApplicants(activeJobId);
    } catch (err) {
      setError('Failed to update status');
    }
  };

  return (
    <Container className="py-4">
      <Row className="mb-3"><Col><h3>Employer Dashboard</h3></Col></Row>
      {message && <Alert variant="success">{message}</Alert>}
      {error && <Alert variant="danger">{error}</Alert>}

      <Card className="mb-4 shadow-sm">
        <Card.Body>
          <Row className="g-3">
            <Col md={4}><Form.Control placeholder="Job Title" value={form.jobTitle} onChange={e=>setForm({...form, jobTitle:e.target.value})} /></Col>
            <Col md={4}><Form.Control placeholder="Company" value={form.company} onChange={e=>setForm({...form, company:e.target.value})} /></Col>
            <Col md={4}><Form.Control placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} /></Col>
            <Col md={6}><Form.Control placeholder="Requirements" value={form.requirements} onChange={e=>setForm({...form, requirements:e.target.value})} /></Col>
            <Col md={6}><Form.Control placeholder="Job Description" value={form.jobDescription} onChange={e=>setForm({...form, jobDescription:e.target.value})} /></Col>
            <Col md={3}><Form.Control type="number" placeholder="Salary" value={form.salary} onChange={e=>setForm({...form, salary:e.target.value})} /></Col>
            <Col md={3}><Button className="w-100" onClick={postJob}>Post Job</Button></Col>
          </Row>
        </Card.Body>
      </Card>

      <Card className="shadow-sm">
        <Card.Body>
          <h5>My Job Listings</h5>
          <Table responsive>
            <thead>
              <tr><th>Title</th><th>Location</th><th>Posted</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {jobs.map(j => (
                <tr key={j.jobId}>
                  <td>{j.jobTitle}</td>
                  <td>{j.location}</td>
                  <td>{new Date(j.postedDate).toLocaleDateString()}</td>
                  <td>
                    <Button size="sm" onClick={()=>openApplicants(j.jobId)}>Applicants</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      <Modal show={showApplicants} onHide={()=>setShowApplicants(false)} size="lg">
        <Modal.Header closeButton><Modal.Title>Applicants</Modal.Title></Modal.Header>
        <Modal.Body>
          <Table responsive>
            <thead><tr><th>ID</th><th>JobSeeker</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {applicants.map(a => (
                <tr key={a.applicationId}>
                  <td>{a.applicationId}</td>
                  <td>{a.jobSeekerId}</td>
                  <td>{a.status}</td>
                  <td>
                    {a.status !== 'Selected' && (
                      <Button size="sm" onClick={()=>selectCandidate(a.applicationId)}>Select</Button>
                    )}
                  </td>
                </tr>
              ))}
              {!applicants.length && <tr><td colSpan="4">No applicants yet</td></tr>}
            </tbody>
          </Table>
        </Modal.Body>
      </Modal>
    </Container>
  );
}
