import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <Container className="py-5">
      <Row className="mb-4">
        <Col>
          <h1 className="fw-bold">Welcome to CareerLync</h1>
          <p className="text-muted">Find jobs, apply quickly, and manage postings in one place.</p>
        </Col>
      </Row>
      <Row>
        <Col md={4} className="mb-3">
          <Card className="h-100 shadow-sm">
            <Card.Body>
              <Card.Title>Job Seekers</Card.Title>
              <Card.Text>Search and apply to jobs, manage your profile and resume.</Card.Text>
              <Button as={Link} to="/register" state={{ role: 'JobSeeker' }}>Get Started</Button>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-3">
          <Card className="h-100 shadow-sm">
            <Card.Body>
              <Card.Title>Employers</Card.Title>
              <Card.Text>Post jobs, edit listings and review applicants.</Card.Text>
              <Button as={Link} to="/register" state={{ role: 'Employer' }}>Post a Job</Button>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-3">
          <Card className="h-100 shadow-sm">
            <Card.Body>
              <Card.Title>Admin</Card.Title>
              <Card.Text>Manage users and keep the platform healthy.</Card.Text>
              <Button as={Link} to="/login">Admin Login</Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
