import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { setToken, setRole, setUid } = useAuth();

  const [userRole, setUserRole] = useState('JobSeeker');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [website, setWebsite] = useState('');
  const [companyDetails, setCompanyDetails] = useState('');
  const [highestEducation, setHighestEducation] = useState('');
  const [skills, setSkills] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (state?.role) setUserRole(state.role);
  }, [state]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = { name, email, password, userRole };
      if (userRole === 'Employer') {
        payload.companyName = companyName;
        payload.website = website;
        payload.companyDetails = companyDetails;
      } else if (userRole === 'JobSeeker') {
        payload.highestEducation = highestEducation;
        payload.skills = skills;
      }
      const res = await api.post('/api/Auth/signup', payload);
      // backend returns { token, message, userRole, uid } (as per earlier discussions)
      const { token, userRole: roleFromServer, uid } = res.data;
      setToken(token);
      setRole(roleFromServer || userRole);
      setUid(uid || null);
      if ((roleFromServer || userRole) === 'Employer') navigate('/employer');
      else navigate('/jobseeker');
    } catch (err) {
      setError(err?.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow-sm">
            <Card.Body>
              <h3 className="mb-4">Create Account</h3>
              {error && <Alert variant="danger">{error}</Alert>}
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Name</Form.Label>
                      <Form.Control value={name} onChange={(e)=>setName(e.target.value)} required />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Email</Form.Label>
                      <Form.Control type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Password</Form.Label>
                      <Form.Control type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Role</Form.Label>
                      <Form.Select value={userRole} onChange={(e)=>setUserRole(e.target.value)}>
                        <option value="JobSeeker">Job Seeker</option>
                        <option value="Employer">Employer</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>

                {userRole === 'Employer' && (
                  <Row>
                    <Col md={4}>
                      <Form.Group className="mb-3">
                        <Form.Label>Company Name</Form.Label>
                        <Form.Control value={companyName} onChange={(e)=>setCompanyName(e.target.value)} required />
                      </Form.Group>
                    </Col>
                    <Col md={4}>
                      <Form.Group className="mb-3">
                        <Form.Label>Website</Form.Label>
                        <Form.Control value={website} onChange={(e)=>setWebsite(e.target.value)} />
                      </Form.Group>
                    </Col>
                    <Col md={4}>
                      <Form.Group className="mb-3">
                        <Form.Label>Company Details</Form.Label>
                        <Form.Control value={companyDetails} onChange={(e)=>setCompanyDetails(e.target.value)} />
                      </Form.Group>
                    </Col>
                  </Row>
                )}

                {userRole === 'JobSeeker' && (
                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Highest Education</Form.Label>
                        <Form.Control value={highestEducation} onChange={(e)=>setHighestEducation(e.target.value)} />
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3">
                        <Form.Label>Skills</Form.Label>
                        <Form.Control value={skills} onChange={(e)=>setSkills(e.target.value)} />
                      </Form.Group>
                    </Col>
                  </Row>
                )}

                <Button type="submit">Sign Up</Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
