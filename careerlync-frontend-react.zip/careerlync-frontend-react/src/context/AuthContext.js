import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [role, setRole] = useState(localStorage.getItem('role'));
  const [uid, setUid] = useState(localStorage.getItem('uid'));

  useEffect(() => {
    if (token) localStorage.setItem('token', token); else localStorage.removeItem('token');
  }, [token]);

  useEffect(() => {
    if (role) localStorage.setItem('role', role); else localStorage.removeItem('role');
  }, [role]);

  useEffect(() => {
    if (uid) localStorage.setItem('uid', uid); else localStorage.removeItem('uid');
  }, [uid]);

  const value = useMemo(() => ({
    token, setToken,
    role, setRole,
    uid, setUid
  }), [token, role, uid]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext);
}
