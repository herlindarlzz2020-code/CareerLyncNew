import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import TopNav from './components/NavBar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import JobSeekerDashboard from './pages/JobSeekerDashboard';
import EmployerDashboard from './pages/EmployerDashboard';
import AdminDashboard from './pages/AdminDashboard';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './utils/PrivateRoute';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <TopNav />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/jobseeker" element={<PrivateRoute allow={['JobSeeker']}><JobSeekerDashboard /></PrivateRoute>} />
          <Route path="/employer" element={<PrivateRoute allow={['Employer']}><EmployerDashboard /></PrivateRoute>} />
          <Route path="/admin" element={<PrivateRoute allow={['Admin']}><AdminDashboard /></PrivateRoute>} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
