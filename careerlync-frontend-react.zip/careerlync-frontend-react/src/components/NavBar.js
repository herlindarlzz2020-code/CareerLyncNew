import React from 'react';
import { Navbar, Container, Nav } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function TopNav() {
  const { token, role, setToken, setRole, setUid } = useAuth();
  const navigate = useNavigate();

  const logout = () => {
    setToken(null);
    setRole(null);
    setUid(null);
    navigate('/login');
  };

  return (
    <Navbar bg="light" expand="lg" className="shadow-sm">
      <Container>
        <Navbar.Brand as={Link} to="/">CareerLync</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">Home</Nav.Link>
            {!token && <Nav.Link as={Link} to="/login">Login</Nav.Link>}
            {!token && <Nav.Link as={Link} to="/register">Register</Nav.Link>}
            {role === 'JobSeeker' && <Nav.Link as={Link} to="/jobseeker">Dashboard</Nav.Link>}
            {role === 'Employer' && <Nav.Link as={Link} to="/employer">Dashboard</Nav.Link>}
            {role === 'Admin' && <Nav.Link as={Link} to="/admin">Dashboard</Nav.Link>}
          </Nav>
          {token && <Nav><Nav.Link onClick={logout}>Logout</Nav.Link></Nav>}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
