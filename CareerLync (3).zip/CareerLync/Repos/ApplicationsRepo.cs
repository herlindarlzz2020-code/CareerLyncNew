﻿using CareerLync.Data;
using CareerLync.Entities;
using Microsoft.EntityFrameworkCore;
namespace CareerLync.Repos
{
    public interface IApplicationsRepo
    {
        Applications? FindByApplicantUid(int uid);
        List<Applications> FindByJobListingPostedByUid(int employerUid);
        Applications? FindByApplicantUidAndJobId(int applicantId, int jobId);

    }
    public class ApplicationsRepo : IApplicationsRepo
    {
        private readonly CareerLyncDbContext _context;
        
        public ApplicationsRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public Applications? FindByApplicantUid(int uid)
        {
            return _context.Applications.FirstOrDefault(a => a.JobSeeker.Uid == uid);
        }

        // Applications by Employer UID via JobListings
        public List<Applications> FindByJobListingPostedByUid(int employerUid)
        {
            return _context.Applications
                .Include(a => a.JobListings)
                .ThenInclude(j => j.Employer)
                .Where(a => a.JobListings.Employer.Uid == employerUid)
                .ToList();
        }

        public Applications? FindByApplicantUidAndJobId(int applicantId, int jobId)
        {
            return _context.Applications
                .FirstOrDefault(a => a.JobSeeker.Uid == applicantId && a.JobListings.JobId == jobId);
        }
    }
}

