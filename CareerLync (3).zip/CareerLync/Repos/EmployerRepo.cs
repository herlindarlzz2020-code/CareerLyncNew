﻿using CareerLync.Data;
using CareerLync.Entities;


namespace CareerLync.Repos
{

    public interface IEmployerRepo
    {
        Employer? FindByEmail(string email);

    }
    public class EmployerRepo : IEmployerRepo
    {
        private readonly CareerLyncDbContext _context;

        public EmployerRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public Employer? FindByEmail(string email)
        {
            return _context.Employers.FirstOrDefault(e => e.Email == email);
        }
    }
}


