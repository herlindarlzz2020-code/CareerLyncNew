﻿// Repository interface
using CareerLync.Data;
using CareerLync.Entities;
using Microsoft.EntityFrameworkCore;
namespace CareerLync.Repos
{
    public interface IUserRepo
    {
        Task<User> GetByIdAsync(int id);
        Task<List<User>> GetAllAsync();


        Task AddAsync(User user);
        Task SaveChangesAsync();
    }

    // Repository implementation
    public class UserRepo : IUserRepo
    {
        private readonly CareerLyncDbContext _context;

        public UserRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public async Task<User> GetByIdAsync(int id)
        {
            return await _context.Users.FindAsync(id);
        }

        public async Task AddAsync(User user)
        {
            await _context.Users.AddAsync(user);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
        public async Task<List<User>> GetAllAsync()
        {
            return await _context.Users.ToListAsync();
        }

    }
}


