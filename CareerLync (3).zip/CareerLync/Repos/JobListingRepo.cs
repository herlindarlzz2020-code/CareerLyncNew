﻿using CareerLync.Data;
using CareerLync.Entities;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Repos


{
    public interface IJobListingsRepo
    {
        List<JobListings> FindByLocation(string location);
        List<JobListings> FindByJobTitle(string jobTitle);
        List<JobListings> FindByCompany(string company);
        List<JobListings> FindByLocationAndJobTitleAndCompany(string location, string jobTitle, string company);
        List<JobListings> FindByEmployerUid(int employerUid);
        List<JobListings> FindByJobTitleAndCompany(string jobTitle, string company);
        List<JobListings> FindByLocationAndCompany(string location, string company);
        List<JobListings> FindByLocationAndJobTitle(string location, string jobTitle);

    }
    public class JobListingRepo : IJobListingsRepo
    {
        private readonly CareerLyncDbContext _context;

        public JobListingRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public List<JobListings> FindByLocation(string location) =>
            _context.JobListings.Where(j => j.Location == location).ToList();

        public List<JobListings> FindByJobTitle(string jobTitle) =>
            _context.JobListings.Where(j => j.JobTitle == jobTitle).ToList();

        public List<JobListings> FindByCompany(string company) =>
            _context.JobListings.Where(j => j.Company == company).ToList();

        public List<JobListings> FindByLocationAndJobTitleAndCompany(string location, string jobTitle, string company) =>
            _context.JobListings.Where(j => j.Location == location && j.JobTitle == jobTitle && j.Company == company).ToList();

        public List<JobListings> FindByLocationAndJobTitle(string location, string jobTitle) =>
            _context.JobListings.Where(j => j.Location == location && j.JobTitle == jobTitle).ToList();

        public List<JobListings> FindByLocationAndCompany(string location, string company) =>
            _context.JobListings.Where(j => j.Location == location && j.Company == company).ToList();

        public List<JobListings> FindByJobTitleAndCompany(string jobTitle, string company) =>
            _context.JobListings.Where(j => j.JobTitle == jobTitle && j.Company == company).ToList();

        public List<JobListings> FindByEmployerUid(int employerUid) =>
            _context.JobListings.Where(j => j.Employer.Uid == employerUid).ToList();
    }
}
