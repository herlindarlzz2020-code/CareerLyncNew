﻿using CareerLync.Entities;
using CareerLync.Data;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Repos
{
    public interface IAdminRepo
    {
        Admin? FindByName(string name);
        Admin? FindByEmail(string email);
        void DeleteEmployer(int id);
    }

    public class AdminRepo : IAdminRepo
    {
        private readonly CareerLyncDbContext _context;

        public AdminRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public Admin? FindByName(string name)
        {
            return _context.Admins.FirstOrDefault(a => a.Name == name);
        }

        public Admin? FindByEmail(string email)
        {
            return _context.Admins.FirstOrDefault(a => a.Email == email);
        }

        public void DeleteEmployer(int id)
        {
            var employer = _context.Employers.Find(id);
            if (employer != null)
            {
                _context.Employers.Remove(employer);
                _context.SaveChanges();
            }
        }
    }
}

