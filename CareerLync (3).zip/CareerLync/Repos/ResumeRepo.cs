﻿using CareerLync.Data;
using CareerLync.Entities;
using Microsoft.EntityFrameworkCore;

namespace CareerLync.Repos
{
    public interface IResumeRepo
    {
        Resume? FindByJobSeekerUid(int jobSeekerId);
        Resume? FindByJobSeeker(JobSeeker jobSeeker);
        bool ExistsByJobSeekerUid(int jobSeekerId);

    }
    public class ResumeRepo : IResumeRepo
    {
        private readonly CareerLyncDbContext _context;

        public ResumeRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public Resume? FindByJobSeekerUid(int jobSeekerId)
        {
            return _context.Resumes.FirstOrDefault(r => r.JobSeeker.Uid == jobSeekerId);
        }

        public Resume? FindByJobSeeker(JobSeeker jobSeeker)
        {
            return _context.Resumes.FirstOrDefault(r => r.JobSeeker.Uid == jobSeeker.Uid);
        }

        public bool ExistsByJobSeekerUid(int jobSeekerId)
        {
            return _context.Resumes.Any(r => r.JobSeeker.Uid == jobSeekerId);
        }
    }
}

