﻿using CareerLync.Data;
using CareerLync.Entities;


namespace CareerLync.Repos
{
    public interface IJobSeekerRepo
    {
        JobSeeker? FindByEmail(string email);
    }
    public class JobSeekerRepo : IJobSeekerRepo
    {
        private readonly CareerLyncDbContext _context;

        public JobSeekerRepo(CareerLyncDbContext context)
        {
            _context = context;
        }

        public JobSeeker? FindByEmail(string email)
        {
            return _context.JobSeekers.FirstOrDefault(js => js.Email == email);
        }
    }
}

