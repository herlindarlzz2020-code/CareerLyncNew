﻿using CareerLync.DTOs;
using CareerLync.Enums;
using CareerLync.Service;
using CareerLync.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class AdminController : ControllerBase
    {
        private readonly IUserService _userService;

        public AdminController(IUserService userService)
        {
            _userService = userService;
        }

        // POST: api/admin/create
        [HttpPost("create")]
        public ActionResult<AdminDTO> CreateAdmin([FromBody] AdminDTO adminDTO)
        {
            adminDTO.UserRole = UserRole.Admin;
            var createdAdmin = (AdminDTO)_userService.SaveUser(adminDTO);
            return Ok(createdAdmin);
        }

        // GET: api/admin/jobs
        [HttpGet("jobs")]
        public ActionResult<IEnumerable<JobListingsDTO>> GetAllJobs()
        {
            var jobs = _userService.GetAllJobs();
            return Ok(jobs);
        }

        // GET: api/admin/employers
        [HttpGet("employers")]
        public ActionResult<IEnumerable<UserDTO>> GetAllEmployers()
        {
            var employers = _userService.GetAllEmployers();
            return Ok(employers);
        }

        // GET: api/admin/jobseekers
        [HttpGet("jobseekers")]
        public ActionResult<IEnumerable<UserDTO>> GetAllJobSeekers()
        {
            var jobSeekers = _userService.GetAllJobSeekers();
            return Ok(jobSeekers);
        }

        // GET: api/admin/applications
        [HttpGet("applications")]
        public ActionResult<IEnumerable<ApplicationDTO>> GetAllApplications()
        {
            return Ok(_userService.GetAllApplications());
        }

        // DELETE: api/admin/job/{jobId}
        [HttpDelete("job/{jobId}")]
        public IActionResult DeleteJob(int jobId)
        {
            _userService.DeleteJob(jobId);
            return NoContent();
        }

        // DELETE: api/admin/user/{userId}
        [HttpDelete("user/{userId}")]
        public IActionResult DeleteUserById(int userId)
        {
            _userService.DeleteUserById(userId);
            return NoContent();
        }

        // GET: api/admin/user/{userId}
        [HttpGet("user/{userId}")]
        public ActionResult<UserDTO> GetUserById(int userId)
        {
            var user = _userService.GetUserById(userId);
            return Ok(user);
        }

        // PUT: api/admin/profile/{uid}
        [HttpPut("profile/{uid}")]
        public ActionResult<AdminDTO> UpdateAdminProfile(int uid, [FromBody] AdminDTO adminDTO)
        {
            var updatedProfile = _userService.UpdateAdminProfile(uid, adminDTO);
            return Ok(updatedProfile);
        }
    }
}

