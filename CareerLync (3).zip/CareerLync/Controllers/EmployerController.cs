﻿using CareerLync.DTOs;
using CareerLync.Enums;
using CareerLync.Service;
using CareerLync.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Controllers
{
    [ApiController]
    [Route("api/employer")]
    [Produces("application/json")]
    public class EmployerController : ControllerBase
    {
        private readonly IUserService _userService;

        public EmployerController(IUserService userService)
        {
            _userService = userService;
        }

        // Create Employer
        [HttpPost("create")]
        public ActionResult<EmployerDTO> CreateEmployer([FromBody] EmployerDTO employerDTO)
        {
            try
            {
                employerDTO.UserRole = UserRole.Employer;

                var result = _userService.SaveUser(employerDTO);

                var createdEmployer = result as EmployerDTO;
                if (createdEmployer == null)
                    return BadRequest("Failed to create Employer");

                return Ok(createdEmployer);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // Post a Job
        [HttpPost("post-job")]
        public ActionResult<JobListingsDTO> PostJob([FromBody] JobListingsDTO jobListingsDTO)
        {
            try
            {
                var createdJob = _userService.PostJob(jobListingsDTO);
                return Ok(createdJob);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // View Applications for a Job
        [HttpGet("job/{jobId}/applications")]
        public ActionResult<IEnumerable<ApplicationDTO>> ViewApplications(int jobId)
        {
            try
            {
                var applications = _userService.ViewApplications(jobId);
                return Ok(applications);
            }
            catch (Exception ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // View all Job Listings posted by Employer
        [HttpGet("my-jobs/{employerId}")]
        public ActionResult<IEnumerable<JobListingsDTO>> GetEmployerJobs(int employerId)
        {
            try
            {
                var jobs = _userService.GetEmployerJobListings(employerId);
                return Ok(jobs);
            }
            catch (Exception ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // Update Employer Profile
        [HttpPut("profile/{uid}")]
        public ActionResult<EmployerDTO> UpdateEmployerProfile(int uid, [FromBody] EmployerDTO employerDTO)
        {
            try
            {
                var updatedProfile = _userService.UpdateEmployerProfile(uid, employerDTO);
                return Ok(updatedProfile);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        // Update Application Status (Employer selects/rejects a candidate)
        [HttpPut("application/{applicationId}/status")]
        public ActionResult<ApplicationDTO> UpdateApplicationStatus(int applicationId, [FromQuery] string status)
        {
            try
            {
                var updatedApplication = _userService.UpdateApplicationStatus(applicationId, status);
                return Ok(updatedApplication);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

    }
}

