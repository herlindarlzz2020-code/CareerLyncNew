﻿using CareerLync.DTOs;
using CareerLync.Service;
using CareerLync.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _authService;

        public AuthController(IUserService authService)
        {
            _authService = authService;
        }

        // POST: api/user/signup
        [HttpPost("signup")]
        public ActionResult<AuthResponse> RegisterUser([FromBody] SignUpDTO signUpDTO)
        {
            try
            {
                string jwt = _authService.CreateUser(signUpDTO);
                return Ok(new AuthResponse
                {
                    Token = jwt,
                    Message = "Registration successful!",
                    UserRole = signUpDTO.UserRole,
                    Uid = 0 // can be filled with the new user's ID if available
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // POST: api/user/signin
        [HttpPost("signin")]
        public ActionResult<AuthResponse> LoginUser([FromBody] LoginDTO loginDTO)
        {
            try
            {
                var response = _authService.LoginUser(loginDTO);
                return Ok(response);
            }
            catch (Exception ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }
    }
}

