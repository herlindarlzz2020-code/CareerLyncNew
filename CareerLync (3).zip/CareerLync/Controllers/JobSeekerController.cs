﻿using CareerLync.DTOs;
using CareerLync.Enums;
using CareerLync.Repos;
using CareerLync.Service;
using CareerLync.Services;
using Microsoft.AspNetCore.Mvc;

namespace CareerLync.Controllers
{
    [ApiController]
    [Route("api/jobseeker")]
    [Produces("application/json")]
    public class JobSeekerController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IResumeRepo _resumeRepository;

        public JobSeekerController(IUserService userService, IResumeRepo resumeRepository)
        {
            _userService = userService;
            _resumeRepository = resumeRepository;
        }

        // Create Job Seeker
        [HttpPost("createjobseeker")]
        public ActionResult<JobSeekerDTO> CreateJobSeeker([FromBody] JobSeekerDTO jobSeekerDTO)
        {
            jobSeekerDTO.UserRole = UserRole.JobSeeker;

            var result = _userService.SaveUser(jobSeekerDTO);

            var createdJobSeeker = result as JobSeekerDTO;
            if (createdJobSeeker == null)
                return BadRequest("Failed to create JobSeeker");

            return Ok(createdJobSeeker);
        }

        // Search Jobs
        [HttpGet("search-jobs")]
        public ActionResult<IEnumerable<JobListingsDTO>> SearchJobs([FromQuery] string keyword)
        {
            var jobs = _userService.SearchJobs(keyword);
            return Ok(jobs);
        }

        // Apply to a Job
        [HttpPost("apply")]
        public ActionResult<ApplicationDTO> CreateApplication([FromBody] ApplicationDTO applicationDTO)
        {
            try
            {
                var createdApplication = _userService.CreateApplication(applicationDTO);
                return Ok(createdApplication);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // View Application by UID
        [HttpGet("viewApplication/{uid}")]
        public ActionResult<ApplicationDTO> ViewApplication(int uid)
        {
            try
            {
                var applicationDTO = _userService.ViewApplicationByUid(uid);
                return Ok(applicationDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("upload-resume")]
        [Consumes("multipart/form-data")]
        public async Task<ActionResult<ResumeDTO>> UploadResume([FromForm] ResumeUploadDTO dto)
        {
            if (dto.File == null || dto.File.Length == 0)
                return BadRequest(new { message = "Invalid file upload" });

            try
            {
                using var memoryStream = new MemoryStream();
                await dto.File.CopyToAsync(memoryStream);

                var resumeDTO = new ResumeDTO
                {
                    ResumeImage = memoryStream.ToArray(),
                    UploadDate = DateTime.Now
                };

                var updatedResume = _userService.CreateOrUpdateResume(dto.JobSeekerId, resumeDTO);
                return Ok(updatedResume);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }


        // Check Resume Status
        [HttpGet("resume-status/{jobSeekerId}")]
        public ActionResult<bool> CheckResumeStatus(int jobSeekerId)
        {
            var hasResume = _resumeRepository.ExistsByJobSeekerUid(jobSeekerId);
            return Ok(hasResume);
        }

        // Update JobSeeker Profile
        [HttpPut("profile/{uid}")]
        public ActionResult<JobSeekerDTO> UpdateJobSeekerProfile(int uid, [FromBody] JobSeekerDTO jobSeekerDTO)
        {
            var updatedProfile = _userService.UpdateJobSeekerProfile(uid, jobSeekerDTO);
            return Ok(updatedProfile);
        }

        // Get Resume Status (returns ResumeDTO)
        [HttpGet("status/{jobSeekerId}")]
        public ActionResult<ResumeDTO> GetResumeStatus(int jobSeekerId)
        {
            var resumeDTO = _userService.GetResumeByJobSeekerId(jobSeekerId);
            return Ok(resumeDTO);
        }
        // View All Applications for a JobSeeker
        [HttpGet("applications/{jobSeekerId}")]
        public ActionResult<IEnumerable<ApplicationDTO>> GetApplicationsByJobSeeker(int jobSeekerId)
        {
            try
            {
                var applications = _userService.GetApplicationsByJobSeeker(jobSeekerId);
                return Ok(applications);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

    }
}
