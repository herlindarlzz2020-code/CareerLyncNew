﻿namespace CareerLync.Enums
{
    public enum ApplicationStatus
    {
        Pending,
        Selected,
        Rejected
    }

}
