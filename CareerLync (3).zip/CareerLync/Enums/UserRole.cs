﻿namespace CareerLync.Enums
{
    public enum UserRole
    {
        Employer,
        JobSeeker,
        Admin
    }
}

