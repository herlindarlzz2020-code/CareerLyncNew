﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CareerLync.DTOs;
using CareerLync.Enums;

namespace CareerLync.Entities
{
    [Table("Employers")]
    public class Employer : User
    {
        [Column("CompanyName")]
        
        public string? CompanyName { get; set; }

        [Column("Website")]
        public string? Website { get; set; }

        [Column("CompanyDetails")]
        public string? CompanyDetails { get; set; }

        // One-to-Many: Employer → JobListings
        public List<JobListings> JobListings { get; set; } = new List<JobListings>();
    

        public Employer() { }

        public Employer(string name, string email, string address, string password,
                        string mob,  UserRole userRole,
                        string companyName, string website, string companyDetails,
                        List<JobListings> jobListings)
            : base(name, email, address, password, mob,userRole)
        {
            CompanyName = companyName;
            Website = website;
            CompanyDetails = companyDetails;
            JobListings = jobListings;
        }

        public EmployerDTO MapToDTO()
        {
            return new EmployerDTO
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
              
                UserRole = this.UserRole,
                CompanyName = this.CompanyName,
                Website = this.Website,
                CompanyDetails = this.CompanyDetails,
                JobListings = this.JobListings
            };
        }
    }
}
