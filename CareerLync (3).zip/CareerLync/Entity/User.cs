﻿using System;
using CareerLync.DTOs;
using CareerLync.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CareerLync.Entities
{
    [Table("Users")]
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Uid { get; set; }

        [Column("Name")]
        public string Name { get; set; }

        [Column("Email")]
        [Required]
        public string Email { get; set; }

        [Column("Address")]
        public string? Address { get; set; }

        [Column("Password")]
        public string Password { get; set; }

        [Column("MobileNumber")]
        public string? Mob { get; set; }


   

        [Column("UserRole")]
        [Required]
        public UserRole UserRole { get; set; }

        public User() { }

        public User(string name, string email, string address, string password, string mob,  UserRole userRole)
        {
            Name = name;
            Email = email;
            Address = address;
            Password = password;
            Mob = mob;
          
            UserRole = userRole;
        }

        public UserDTO MapToDTO()
        {
            return new UserDTO
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
              
                UserRole = this.UserRole
            };
        }
    }
}
