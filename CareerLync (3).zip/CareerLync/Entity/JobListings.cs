﻿using CareerLync.DTOs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static System.Net.Mime.MediaTypeNames;

namespace CareerLync.Entities
{
    [Table("JobListings")]
    public class JobListings
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int JobId { get; set; }

        [Required]
        [Column("JobTitle")]
        public string JobTitle { get; set; }

        [Column("Company")]
        public string Company { get; set; }

        [Column("JobDescription")]
        public string JobDescription { get; set; }

        [Column("Location")]
        public string Location { get; set; }

        [Column("Requirements")]
        public string Requirements { get; set; }

        [Column("Salary")]
        public int Salary { get; set; }

        [Column("PostedDate")]
        public DateTime PostedDate { get; set; }

        // One-to-Many: JobListings → Applications
        public virtual ICollection<Applications> Applications { get; set; } = new List<Applications>();

        // Many-to-One: JobListings → Employer
        [ForeignKey("EmployerId")]
        public int EmployerId { get; set; }

        public virtual Employer Employer { get; set; }

        public JobListings() { }

        public JobListings(string jobTitle, string company, string jobDescription,
                           string location, string requirements, int salary, DateTime postedDate)
        {
            JobTitle = jobTitle;
            Company = company;
            JobDescription = jobDescription;
            Location = location;
            Requirements = requirements;
            Salary = salary;
            PostedDate = postedDate;
        }

        public JobListingsDTO MapToDTO()
        {
            return new JobListingsDTO
            {
                JobId = this.JobId,
                JobTitle = this.JobTitle,
                Company = this.Company,
                JobDescription = this.JobDescription,
                Location = this.Location,
                Requirements = this.Requirements,
                Salary = this.Salary,
                PostedDate = this.PostedDate
            };
        }
    }
}
