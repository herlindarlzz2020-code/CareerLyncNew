﻿using System;
using CareerLync.DTOs;

namespace CareerLync.Entities
{
    public class Resume
    {
        public int ResumeId { get; set; }

        // In C#, we can use byte[] for file/image storage
        public byte[] ResumeImage { get; set; }

        public DateTime UploadDate { get; set; }

        // Foreign key to JobSeeker
        public int JobSeekerId { get; set; }
        public JobSeeker JobSeeker { get; set; }

        // DTO Mapper
        public ResumeDTO MapToDTO()
        {
            return new ResumeDTO
            {
                ResumeId = this.ResumeId,
                ResumeImage = this.ResumeImage,
                UploadDate = this.UploadDate,
                JobSeekerId = this.JobSeekerId
            };
        }
    }
}
