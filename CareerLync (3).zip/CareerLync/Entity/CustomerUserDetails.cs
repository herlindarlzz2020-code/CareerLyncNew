﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Security.Claims;
using CareerLync.Enums;

namespace CareerLync.Entities
{
    public class CustomUserDetails : IdentityUser<int> // use int as PK like your uid
    {
        public UserRole UserRole { get; set; }

        // Constructor
        public CustomUserDetails(int uid, string username, string password, UserRole userRole)
        {
            Id = uid;
            UserName = username;
            PasswordHash = password; // ASP.NET Identity expects hashed passwords
            UserRole = userRole;
        }

        public CustomUserDetails() { }

        // Map UserRole -> Claims (like Spring Security authorities)
        public IList<Claim> GetAuthorities()
        {
            return new List<Claim>
            {
                new Claim(ClaimTypes.Role, "ROLE_" + UserRole.ToString())
            };
        }

        // ASP.NET Core Identity already manages account lock/expire/enable checks
        public bool IsAccountNonExpired => true;
        public bool IsAccountNonLocked => true;
        public bool IsCredentialsNonExpired => true;
        public bool IsEnabled => true;
    }
}
