﻿using CareerLync.DTOs;
using CareerLync.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CareerLync.Entities
{
    [Table("Applications")]
    public class Applications
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ApplicationId { get; set; }

        [Required]
        [Column("Status")]
        public ApplicationStatus Status { get; set; } = ApplicationStatus.Pending;


        [Column("AppliedDate")]
        public DateTime AppliedDate { get; set; }

        // Many-to-One: Applications → JobSeeker
        [ForeignKey("JobSeekerId")]
        public int JobSeekerId { get; set; }
        public virtual JobSeeker JobSeeker { get; set; }   // ✅ Only one navigation

        // Many-to-One: Applications → JobListings
        [ForeignKey("JobListingId")]
        public int JobListingId { get; set; }
        public virtual JobListings JobListings { get; set; }

        // One-to-One: Applications → Resume
        [ForeignKey("ResumeId")]
        public int ResumeId { get; set; }
        public virtual Resume Resume { get; set; }

        public Applications() { }

        public Applications(ApplicationStatus status, DateTime appliedDate, JobSeeker jobSeeker, JobListings jobListings, Resume resume)
        {
            Status = status;
            AppliedDate = appliedDate;
            JobSeeker = jobSeeker;
            JobListings = jobListings;
            Resume = resume;
        }

        public ApplicationDTO MapToDTO()
        {
            return new ApplicationDTO(
                this.ApplicationId,
                this.Status,
                this.AppliedDate,
                this.JobSeeker != null ? this.JobSeeker.Uid : this.JobSeekerId,      // ✅ Only one reference
                this.JobListings != null ? this.JobListings.JobId : this.JobSeekerId,
                this.Resume != null ? this.Resume.ResumeId : this.ResumeId
            );
        }
    }
}
