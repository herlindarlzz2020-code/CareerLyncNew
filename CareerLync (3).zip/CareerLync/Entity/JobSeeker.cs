﻿using CareerLync.DTOs;
using CareerLync.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using static System.Net.Mime.MediaTypeNames;

namespace CareerLync.Entities
{
    [Table("JobSeekers")] // EF Core will create separate table for JobSeeker (Joined inheritance)
    public class JobSeeker : User
    {
        [Column("HighestEducation")]
        public string? HighestEducation { get; set; }

        [Column("Skills")]
        public string? Skills { get; set; }

        // One-to-Many: JobSeeker → Applications
        public virtual List<Applications> Applications { get; set; } = new List<Applications>();
        

        // One-to-One: JobSeeker → Resume
        public virtual Resume? Resume { get; set; }

        public JobSeeker() { }

        public JobSeeker(string name, string email, string address, string password,
                         string mob,UserRole userRole,
                         string highestEducation, string skills,
                         List<Applications> applications, Resume resume)
            : base(name, email, address, password, mob, userRole)
        {
            HighestEducation = highestEducation;
            Skills = skills;
            Applications = applications;
            Resume = resume;
        }

        public JobSeekerDTO MapToDTO()
        {
            return new JobSeekerDTO
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
               
                UserRole = this.UserRole,
                HighestEducation = this.HighestEducation,
                Skills = this.Skills,
                
            };
        }
    }
}

