﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using CareerLync.DTOs;
using CareerLync.Enums;

namespace CareerLync.Entities
{
    [Table("Admins")]
    public class Admin : User
    {
        [Column("Privllage")]
        public string Privllage { get; set; }

        public Admin() { }

        public Admin(string name, string email, string address, string password, string mob, UserRole userRole, string privllage)
            : base(name, email, address, password, mob,userRole)
        {
            Privllage = privllage;
        }

        public AdminDTO MapToDTO()
        {
            return new AdminDTO
            {
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
              
                UserRole = this.UserRole,
                Privllage = this.Privllage
            };
        }
    }
}

