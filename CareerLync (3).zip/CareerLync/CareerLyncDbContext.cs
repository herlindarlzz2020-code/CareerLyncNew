﻿using CareerLync.Entities;
using Microsoft.EntityFrameworkCore;
 // update with your actual namespace

namespace CareerLync.Data
{
    public class CareerLyncDbContext : DbContext
    {
        public CareerLyncDbContext(DbContextOptions<CareerLyncDbContext> options)
            : base(options)
        {
        }

        // DbSets = tables
        public DbSet<User> Users { get; set; }
        public DbSet<Employer> Employers { get; set; }
        public DbSet<JobSeeker> JobSeekers { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<JobListings> JobListings { get; set; }
        public DbSet<Applications> Applications { get; set; }
        public DbSet<Resume> Resumes { get; set; }

        // Optional: Fluent API config if needed
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Applications>()
               .HasOne(a => a.JobSeeker)
               .WithMany(js => js.Applications)
               .HasForeignKey(a => a.JobSeekerId)
               .OnDelete(DeleteBehavior.Restrict);   // ✅ prevent cascade cycle

            // Applications → JobListings
            modelBuilder.Entity<Applications>()
                .HasOne(a => a.JobListings)
                .WithMany(j => j.Applications)
                .HasForeignKey(a => a.JobListingId)
                .OnDelete(DeleteBehavior.Restrict);

            // Applications → Resume (1:1)
            modelBuilder.Entity<Applications>()
                .HasOne(a => a.Resume)
                .WithOne()
                .HasForeignKey<Applications>(a => a.ResumeId)
                .OnDelete(DeleteBehavior.Restrict);

            // JobListings → Employer
            modelBuilder.Entity<JobListings>()
                .HasOne(j => j.Employer)
                .WithMany(e => e.JobListings)
                .HasForeignKey(j => j.EmployerId);
        }

    }
}
