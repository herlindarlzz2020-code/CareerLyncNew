﻿namespace CareerLync.Config
{
    public class JwtSettings
    {
        public string Key { get; set; }      // Secret key (like your SECRET_KEY)
        public string Issuer { get; set; }   // Who issues the token
        public string Audience { get; set; } // Who the token is valid for
        public int ExpireMinutes { get; set; } // Expiration in minutes
    }
}

