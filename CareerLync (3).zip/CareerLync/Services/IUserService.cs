﻿
using CareerLync.DTOs;
using System.Collections.Generic;

namespace CareerLync.Service
{
    public interface IUserService
    {
        // Common user management
        UserDTO SaveUser(UserDTO userDTO);

        // JobSeeker-specific methods
        List<JobListingsDTO> SearchJobs(string keyword);
        ApplicationDTO CreateApplication(ApplicationDTO applicationDTO);
        ResumeDTO CreateOrUpdateResume(int jobSeekerId, ResumeDTO resumeDTO);

        // Employer-specific methods
        JobListingsDTO PostJob(JobListingsDTO jobListingDTO);
        List<ApplicationDTO> ViewApplications(int jobListingId);
        List<JobListingsDTO> GetEmployerJobListings(int employerId);

        // Admin-specific methods
        string CreateUser(SignUpDTO signUpRequest);
        AuthResponse LoginUser(LoginDTO loginRequest);
        List<JobListingsDTO> GetAllJobs();
        List<EmployerDTO> GetAllEmployers();
        List<JobSeekerDTO> GetAllJobSeekers();
        List<ApplicationDTO> GetAllApplications();
        void DeleteJob(int jobId);
        void DeleteUserById(int uid);
        List<UserDTO> GetAllUsers();
        UserDTO GetUserById(int uid);
        EmployerDTO UpdateEmployerProfile(int uid, EmployerDTO employerDTO);
        JobSeekerDTO UpdateJobSeekerProfile(int uid, JobSeekerDTO jobSeekerDTO);
        AdminDTO UpdateAdminProfile(int uid, AdminDTO adminDTO);

        ResumeDTO GetResumeByJobSeekerId(int jobSeekerId);
        ApplicationDTO ViewApplicationByUid(int uid);
        ApplicationDTO UpdateApplicationStatus(int applicationId, string status);
        IEnumerable<ApplicationDTO> GetApplicationsByJobSeeker(int jobSeekerId);

    }
}


