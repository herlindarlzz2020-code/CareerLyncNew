﻿using CareerLync.Config;
using CareerLync.Data;
using CareerLync.DTOs;
using CareerLync.Entities;
using CareerLync.Enums;
using CareerLync.Service;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace CareerLync.Services
{
    public class UserServiceImpl : IUserService
    {
        private readonly CareerLyncDbContext _context;
        private readonly JwtProvider _jwtProvider;

        public UserServiceImpl(CareerLyncDbContext context, JwtProvider jwtProvider)
        {
            _context = context;
            _jwtProvider = jwtProvider;
        }

        // -------------------- USER MANAGEMENT --------------------

        public UserDTO SaveUser(UserDTO dto)
        {
            if (dto.UserRole == UserRole.JobSeeker)
            {
                var jobSeekerDto = (JobSeekerDTO)dto;
                var entity = jobSeekerDto.MapToEntity();
                _context.JobSeekers.Add(entity);
                _context.SaveChanges();

                return new JobSeekerDTO(
                    entity.Name,
    entity.Email,
    entity.Address,
    entity.Password,
    entity.Mob,
    entity.HighestEducation,
    entity.Skills
                );
            }
            else if (dto.UserRole == UserRole.Employer)
            {
                var employerDto = (EmployerDTO)dto;
                var entity = employerDto.MapToEntity();
                _context.Employers.Add(entity);
                _context.SaveChanges();

                return new EmployerDTO(
                    entity.Name, entity.Email, entity.Address, entity.Password,
                    entity.Mob,  entity.UserRole,
                    entity.CompanyName, entity.Website, entity.CompanyDetails, entity.JobListings ?? new List<JobListings>()
                );
            }

            throw new Exception("Unsupported role");
        }



        public string Login(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (user == null)
            {
                throw new Exception("Invalid credentials");
            }

            // ✅ Generate JWT using JwtProvider
            return _jwtProvider.GenerateToken(user.Email, user.UserRole.ToString());
        }

        public string CreateUser(SignUpDTO dto)
        {
            if (dto.UserRole == UserRole.JobSeeker)
            {
                var js = new JobSeeker
                {
                    Name = dto.Name,
                    Email = dto.Email,
                    Password = dto.Password,
                    UserRole = dto.UserRole,
                    HighestEducation = dto.HighestEducation ?? "",
                    Skills = dto.Skills ?? "",
                    Address = "",   // default
                    Mob = "",       // default
                    
                };

                _context.JobSeekers.Add(js);
                _context.SaveChanges();

                return _jwtProvider.GenerateToken(dto.Email, dto.UserRole.ToString());
            }
            else if (dto.UserRole == UserRole.Employer)
            {
                var emp = new Employer
                {
                    Name = dto.Name,
                    Email = dto.Email,
                    Password = dto.Password,
                    UserRole = dto.UserRole,
                    CompanyName = dto.CompanyName ?? throw new Exception("Company name is required"),
                    Website = dto.Website ?? "",
                    CompanyDetails = dto.CompanyDetails ?? "",
                    Address = "",
                    Mob = ""
                    
                };

                _context.Employers.Add(emp);
                _context.SaveChanges();

                return _jwtProvider.GenerateToken(dto.Email, dto.UserRole.ToString());
            }

            throw new Exception("Invalid user role");
        }





        public AuthResponse LoginUser(LoginDTO loginRequest)
        {
            var user = _context.Users
                .FirstOrDefault(u => u.Email == loginRequest.Email && u.Password == loginRequest.Password);

            if (user == null) return null;

            return new AuthResponse
            {
                Uid = user.Uid,
                Email = user.Email,
                UserRole = user.UserRole,
                Token = "dummy-token" // replace with JWT if needed
            };
        }

        public void DeleteUserById(int uid)
        {
            var user = _context.Users.Find(uid);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }

        public List<UserDTO> GetAllUsers()
        {
            return _context.Users.Select(u => u.MapToDTO()).ToList();
        }

        public UserDTO GetUserById(int uid)
        {
            var user = _context.Users.Find(uid);
            return user?.MapToDTO();
        }

        // -------------------- JOB SEEKER --------------------

        public List<JobListingsDTO> SearchJobs(string keyword)
        {
            return _context.JobListings
                .Where(j => j.JobTitle.Contains(keyword) || j.Company.Contains(keyword) || j.JobDescription.Contains(keyword))
                .Select(j => j.MapToDTO())
                .ToList();
        }

        public ApplicationDTO CreateApplication(ApplicationDTO dto)
        {
            var app = new Applications
            {
                Status = dto.Status,
                AppliedDate = dto.AppliedDate,
                JobSeekerId = dto.JobSeekerId,
                JobListingId = dto.JobListingId,
                ResumeId = dto.ResumeId
            };

            _context.Applications.Add(app);
            _context.SaveChanges();

            return app.MapToDTO();
        }

        public ResumeDTO CreateOrUpdateResume(int jobSeekerId, ResumeDTO dto)
        {
            var existing = _context.Resumes.FirstOrDefault(r => r.JobSeekerId == jobSeekerId);
            if (existing != null)
            {
                existing.ResumeImage = dto.ResumeImage;
                existing.UploadDate = DateTime.Now;
            }
            else
            {
                existing = new Resume
                {
                    ResumeImage = dto.ResumeImage,
                    UploadDate = DateTime.Now,
                    JobSeekerId = jobSeekerId
                };
                _context.Resumes.Add(existing);
            }

            _context.SaveChanges();
            return existing.MapToDTO();
        }

        public ResumeDTO GetResumeByJobSeekerId(int jobSeekerId)
        {
            var resume = _context.Resumes.FirstOrDefault(r => r.JobSeekerId == jobSeekerId);
            return resume?.MapToDTO();
        }

        public ApplicationDTO ViewApplicationByUid(int uid)
        {
            var app = _context.Applications.Include(a => a.JobListings).Include(a => a.JobSeeker)
                .FirstOrDefault(a => a.JobSeekerId == uid);
            return app?.MapToDTO();
        }

        public JobSeekerDTO UpdateJobSeekerProfile(int uid, JobSeekerDTO dto)
        {
            var seeker = _context.JobSeekers.Include(j => j.Applications).Include(j => j.Resume).FirstOrDefault(j => j.Uid == uid);
            if (seeker == null) return null;

            seeker.Name = dto.Name;
            seeker.Email = dto.Email;
            seeker.Address = dto.Address;
            seeker.Password = dto.Password;
            seeker.Mob = dto.Mob;
            
            seeker.HighestEducation = dto.HighestEducation;
            seeker.Skills = dto.Skills;

            _context.SaveChanges();
            return seeker.MapToDTO();
        }

        // -------------------- EMPLOYER --------------------

        public JobListingsDTO PostJob(JobListingsDTO dto)
        {
            var job = new JobListings
            {
                JobTitle = dto.JobTitle,
                Company = dto.Company,
                JobDescription = dto.JobDescription,
                Location = dto.Location,
                Requirements = dto.Requirements,
                Salary = dto.Salary,
                PostedDate = DateTime.Now,
                EmployerId = dto.EmployerId
            };

            _context.JobListings.Add(job);
            _context.SaveChanges();
            return job.MapToDTO();
        }

        public List<ApplicationDTO> ViewApplications(int jobListingId)
        {
            return _context.Applications
                .Where(a => a.JobListingId == jobListingId)
                .Select(a => a.MapToDTO())
                .ToList();
        }

        public List<JobListingsDTO> GetEmployerJobListings(int employerId)
        {
            return _context.JobListings
                .Where(j => j.EmployerId == employerId)
                .Select(j => j.MapToDTO())
                .ToList();
        }

        public EmployerDTO UpdateEmployerProfile(int uid, EmployerDTO dto)
        {
            var emp = _context.Employers.Include(e => e.JobListings).FirstOrDefault(e => e.Uid == uid);
            if (emp == null) return null;

            emp.Name = dto.Name;
            emp.Email = dto.Email;
            emp.Address = dto.Address;
            emp.Password = dto.Password;
            emp.Mob = dto.Mob;
           
            emp.CompanyName = dto.CompanyName;
            emp.Website = dto.Website;
            emp.CompanyDetails = dto.CompanyDetails;

            _context.SaveChanges();
            return emp.MapToDTO();
        }

        // -------------------- ADMIN --------------------

        public List<JobListingsDTO> GetAllJobs()
        {
            return _context.JobListings.Select(j => j.MapToDTO()).ToList();
        }

        public List<EmployerDTO> GetAllEmployers()
        {
            return _context.Employers.Select(e => e.MapToDTO()).ToList();
        }

        public List<JobSeekerDTO> GetAllJobSeekers()
        {
            return _context.JobSeekers.Select(j => j.MapToDTO()).ToList();
        }

        public List<ApplicationDTO> GetAllApplications()
        {
            return _context.Applications.Select(a => a.MapToDTO()).ToList();
        }

        public void DeleteJob(int jobId)
        {
            var job = _context.JobListings.Find(jobId);
            if (job != null)
            {
                _context.JobListings.Remove(job);
                _context.SaveChanges();
            }
        }

        public AdminDTO UpdateAdminProfile(int uid, AdminDTO dto)
        {
            var admin = _context.Admins.FirstOrDefault(a => a.Uid == uid);
            if (admin == null) return null;

            admin.Name = dto.Name;
            admin.Email = dto.Email;
            admin.Address = dto.Address;
            admin.Password = dto.Password;
            admin.Mob = dto.Mob;
           
            admin.Privllage = dto.Privllage;

            _context.SaveChanges();
            return admin.MapToDTO();
        }
        public ApplicationDTO UpdateApplicationStatus(int applicationId, string status)
        {
            var application = _context.Applications.FirstOrDefault(a => a.ApplicationId == applicationId);
            if (application == null) throw new Exception("Application not found");

            // Convert string → Enum
            if (!Enum.TryParse<ApplicationStatus>(status, true, out var newStatus))
            {
                throw new Exception("Invalid status value");
            }

            application.Status = newStatus;
            _context.SaveChanges();

            return application.MapToDTO();
        }
        public IEnumerable<ApplicationDTO> GetApplicationsByJobSeeker(int jobSeekerId)
        {
            return _context.Applications
                .Where(a => a.JobSeekerId == jobSeekerId)
                .Select(a => a.MapToDTO())
                .ToList();
        }



    }
}
