﻿using CareerLync.Data;
using CareerLync.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace CareerLync.Services
{
    public class CustomUserService
    {
        private readonly CareerLyncDbContext _context;
        private readonly IPasswordHasher<CustomUserDetails> _passwordHasher;

        public CustomUserService(CareerLyncDbContext context, IPasswordHasher<CustomUserDetails> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        public async Task<CustomUserDetails> LoadUserByUsernameAsync(string username)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == username);

            if (user != null)
            {
                // Wrap DB user into CustomUserDetails (like Java did)
                return new CustomUserDetails(
                    user.Uid,
                    user.Email,
                    user.Password,     // ⚠️ Ensure this is already hashed!
                    user.UserRole
                );
            }

            throw new Exception("User not found."); // same as UsernameNotFoundException in Java
        }
    }
}

