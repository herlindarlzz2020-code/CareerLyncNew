﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace CareerLync.Data
{
    public class CareerLyncDbContextFactory : IDesignTimeDbContextFactory<CareerLyncDbContext>
    {
        public CareerLyncDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CareerLyncDbContext>();

            // ⚠️ Make sure this matches your appsettings.json connection string
            optionsBuilder.UseSqlServer("Server=ADMIN;Database=CareerLyncDb;Trusted_Connection=True;TrustServerCertificate=True;");

            return new CareerLyncDbContext(optionsBuilder.Options);
        }
    }
}

