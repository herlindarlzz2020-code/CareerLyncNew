﻿using CareerLync.Config;
using CareerLync.Data;
using CareerLync.Repos;
using CareerLync.Service;
using CareerLync.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// 1. Add DbContext
builder.Services.AddDbContext<CareerLyncDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2. JWT Settings
var jwtSettings = builder.Configuration.GetSection("Jwt").Get<JwtSettings>();
if (jwtSettings == null)
    throw new Exception("Jwt settings are missing in appsettings.json");

// 3. Authentication (only once!)
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings.Issuer,
        ValidAudience = jwtSettings.Audience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.Key))
    };
});

// 4. Authorization
builder.Services.AddAuthorization();

// 5. Dependency Injection
builder.Services.AddScoped<JwtProvider>();

builder.Services.AddScoped<IUserService, UserServiceImpl>();
builder.Services.AddScoped<IUserRepo, UserRepo>();
builder.Services.AddScoped<IJobListingsRepo, JobListingRepo>();
builder.Services.AddScoped<IEmployerRepo, EmployerRepo>();
builder.Services.AddScoped<IJobSeekerRepo, JobSeekerRepo>();
builder.Services.AddScoped<IResumeRepo, ResumeRepo>();
builder.Services.AddScoped<ApplicationsRepo, ApplicationsRepo>();

// 6. Controllers + Swagger
 // add at the top

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // ✅ Allows enums to be passed as strings like "JobSeeker" instead of numbers
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "CareerLync API", Version = "v1" });

    // Enable file upload handling
    c.OperationFilter<FileUploadOperationFilter>();
});


var app = builder.Build();

// Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors(x => x.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();


