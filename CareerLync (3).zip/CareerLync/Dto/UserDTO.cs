﻿using System;
using CareerLync.Entities;
using CareerLync.Enums;

namespace CareerLync.DTOs
{
    public class UserDTO
    {
        public int Uid { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string Mob { get; set; }
       
        public UserRole UserRole { get; set; }

        public UserDTO() { }

        public UserDTO(string name, string email, string address, string password, string mob, UserRole userRole)
        {
            this.Name = name;
            this.Email = email;
            this.Address = address;
            this.Password = password;
            this.Mob = mob;
        
            this.UserRole = userRole;
        }

        // Mapping DTO -> Entity
        public User MapToEntity()
        {
            return new User
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
         
                UserRole = this.UserRole
            };
        }
    }
}

