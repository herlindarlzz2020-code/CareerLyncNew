﻿public class ResumeUploadDTO
{
    public int JobSeekerId { get; set; }
    public IFormFile File { get; set; }
}
