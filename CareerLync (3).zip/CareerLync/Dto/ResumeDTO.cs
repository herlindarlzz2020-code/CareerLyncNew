﻿using System;
using CareerLync.Entities;

namespace CareerLync.DTOs
{
    public class ResumeDTO
    {
        public int ResumeId { get; set; }
        public byte[] ResumeImage { get; set; }
        public DateTime UploadDate { get; set; }
        public int JobSeekerId { get; set; } // Only store JobSeeker ID

        public ResumeDTO() { }

        // DTO → Entity Mapping
        public Resume MapToEntity()
        {
            return new Resume
            {
                ResumeId = this.ResumeId,
                ResumeImage = this.ResumeImage,
                UploadDate = this.UploadDate,
                JobSeekerId = this.JobSeekerId // FK mapping
            };
        }
    }
}

