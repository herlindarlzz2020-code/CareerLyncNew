﻿using CareerLync.Entities;
using CareerLync.Enums;
using System;

namespace CareerLync.DTOs
{
    public class JobSeekerDTO : UserDTO
    {
        public string HighestEducation { get; set; }
        public string Skills { get; set; }

        public JobSeekerDTO() { }

        public JobSeekerDTO(string name, string email, string address, string password, string mob,
                            string highestEducation, string skills)
            : base(name, email, address, password, mob, UserRole.JobSeeker)
        {
            this.HighestEducation = highestEducation;
            this.Skills = skills;
        }

        // Mapping DTO -> Entity
        public JobSeeker MapToEntity()
        {
            return new JobSeeker
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,
                UserRole = UserRole.JobSeeker,
                HighestEducation = this.HighestEducation,
                Skills = this.Skills
                // ❌ Do not map Applications/Resume here (those come later in separate APIs)
            };
        }
    }
}
