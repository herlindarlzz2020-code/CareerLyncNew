﻿using CareerLync.Enums;

namespace CareerLync.DTOs
{
    public class AuthResponse
    {
        public string Jwt { get; set; }
        public string Message { get; set; }
        public UserRole UserRole { get; set; }
        public int Uid { get; set; }
        public string Email { get; set; }
        public string Token { get; set; }


        public AuthResponse(string jwt, string message, UserRole userRole, int uid)
        {
            Jwt = jwt;
            Message = message;
            UserRole = userRole;
            Uid = uid;
        }

        public AuthResponse() { }
    }
}
