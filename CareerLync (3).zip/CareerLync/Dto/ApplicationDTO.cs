﻿using CareerLync.Entities;
using CareerLync.Enums;
using System;

namespace CareerLync.DTOs
{
    public class ApplicationDTO
    {
        public int ApplicationId { get; set; }
        public ApplicationStatus Status { get; set; }
        public DateTime AppliedDate { get; set; }
        
        public int JobListingId { get; set; }
        public int ResumeId { get; set; }
        public int JobSeekerId { get; set; }


        public ApplicationDTO() { }

        public ApplicationDTO(int applicationId, ApplicationStatus status, DateTime appliedDate,
                              int jobSeekerId, int jobListingId, int resumeId)
        {
            ApplicationId = applicationId;
            Status = status;
            AppliedDate = appliedDate;
            JobSeekerId = jobSeekerId;
            JobListingId = jobListingId;
            ResumeId = resumeId;
        }

        // Mapping to Entity
        public Applications MapToEntity()
        {
            return new Applications
            {
                ApplicationId = this.ApplicationId,
                Status = this.Status,
                AppliedDate = this.AppliedDate
                // Applicant, JobListing, Resume to be set externally in service layer
            };
        }
    }
}
