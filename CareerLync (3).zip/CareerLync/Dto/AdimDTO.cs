﻿using System;
using CareerLync.Entities;
using CareerLync.Enums;

namespace CareerLync.DTOs
{
    public class AdminDTO : UserDTO
    {
        public string Privllage { get; set; }

        public AdminDTO() { }

        public AdminDTO(string name, string email, string address, string password, string mob, UserRole userRole, string privllage)
            : base(name, email, address, password, mob, userRole)
        {
            this.UserRole = UserRole.Admin; // Force role as ADMIN
            this.Privllage = privllage;
        }

        // DTO → Entity Mapping
        public Admin MapToEntity()
        {
            return new Admin
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,

                UserRole = UserRole.Admin,
                Privllage = this.Privllage
            };
        }
    }
}

