﻿using System;
using System.Collections.Generic;
using CareerLync.Entities;

namespace CareerLync.DTOs
{
    public class JobListingsDTO
    {
        public int JobId { get; set; }
        public string JobTitle { get; set; }
        public string Company { get; set; }
        public string JobDescription { get; set; }
        public string Location { get; set; }
        public string Requirements { get; set; }
        public int Salary { get; set; }
        public DateTime PostedDate { get; set; }
        public int EmployerId { get; set; }

        public Employer Employer { get; set; }

        public List<Applications> Applications { get; set; }


        public JobListingsDTO() { }

        public JobListingsDTO(int jobId, string jobTitle, string company, string jobDescription, string location,
            string requirements, int salary, DateTime postedDate, List<Applications> applications, Employer employer)
        {
            this.JobId = jobId;
            this.JobTitle = jobTitle;
            this.Company = company;
            this.JobDescription = jobDescription;
            this.Location = location;
            this.Requirements = requirements;
            this.Salary = salary;
            this.PostedDate = postedDate;
            this.Applications = applications;
            this.Employer = employer;
        }

        // DTO → Entity Mapping
        public JobListings MapToEntity()
        {
            return new JobListings
            {
                JobId = this.JobId,
                JobTitle = this.JobTitle,
                Company = this.Company,
                JobDescription = this.JobDescription,
                Location = this.Location,
                Requirements = this.Requirements,
                Salary = this.Salary,
                PostedDate = this.PostedDate,
                Applications = this.Applications,
                Employer = this.Employer
            };
        }
    }
}


