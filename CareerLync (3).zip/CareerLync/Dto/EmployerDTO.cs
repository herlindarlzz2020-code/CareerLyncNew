﻿using System;
using System.Collections.Generic;
using CareerLync.Entities;
using CareerLync.Enums;

namespace CareerLync.DTOs
{
    public class EmployerDTO : UserDTO
    {
        public string CompanyName { get; set; }
        public string Website { get; set; }
        public string CompanyDetails { get; set; }
        public List<JobListings> JobListings { get; set; }

        public EmployerDTO() { }

        public EmployerDTO(string name, string email, string address, string password, string mob,
                           UserRole userRole, string companyName, string website, string companyDetails, List<JobListings> jobListings)
            : base(name, email, address, password, mob,  userRole)
        {
            this.UserRole = UserRole.Employer; // force role to EMPLOYER
            this.CompanyName = companyName;
            this.Website = website;
            this.CompanyDetails = companyDetails;
            this.JobListings = jobListings;
        }

        // Mapping DTO -> Entity
        public Employer MapToEntity()
        {
            return new Employer
            {
                Uid = this.Uid,
                Name = this.Name,
                Email = this.Email,
                Address = this.Address,
                Password = this.Password,
                Mob = this.Mob,

                UserRole = UserRole.Employer,
                CompanyName = this.CompanyName,
                Website = this.Website,
                CompanyDetails = this.CompanyDetails,
                JobListings = this.JobListings
            };
        }
    }
}

