﻿using CareerLync.Enums;
using System.ComponentModel.DataAnnotations;

namespace CareerLync.DTOs
{
    public class SignUpDTO
    {
        // Common Fields

        [Required] 
        public string Name { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
        public UserRole UserRole { get; set; }

        // Employer-specific Fields
        public string? CompanyName { get; set; }
        public string? Website { get; set; }
        public string? CompanyDetails { get; set; }

        // JobSeeker-specific Fields
        public string? HighestEducation { get; set; }
        public string? Skills { get; set; }

        // Admin-specific Fields
        public string? Privilege { get; set; }
    }
}

